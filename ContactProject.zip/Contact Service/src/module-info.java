module Three {
	requires org.junit.jupiter.api;
}