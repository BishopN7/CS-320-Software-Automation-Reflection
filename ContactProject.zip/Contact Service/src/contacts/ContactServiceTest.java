package contacts;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {
	
	// Test for adding contacts
	@Test 
	public void testAddContact() {
		ContactService service = new ContactService();
		Contact c = new Contact("1", "John", "Smith", "1234567890", "123 Main St");
		
		service.addContact(c);
		
		// Confirmation to see if it was added via update
		service.updateFirstName("1", "NewName");
		assertEquals("NewName", c.getFirstName());
		
	}
	
	// Test for duplicate ID
	@Test
	public void testDuplicateID() {
		ContactService service = new ContactService();
		Contact c1 = new Contact ("1", "John", "Smith", "1234567890", "123 Main St");
		Contact c2 = new Contact ("1", "Jane", "Smith", "0987654321", "232 Oak St");
		
		service.addContact(c1);
		
		assertThrows(IllegalArgumentException.class, () -> {
			service.addContact(c2);
		});
	}
	
	// Test for deleting contacts
	@Test
	public void testDeleteContact() {
		ContactService service = new ContactService();
		Contact c = new Contact ("1", "John", "Smith", "1234567890", "123 Main St");
		
		service.addContact(c);
		service.updateFirstName("1", "John");
		
		assertEquals("John", c.getFirstName());
	}
	
	// Test for updating last name
	@Test
	public void testUpdateLastName() {
		ContactService service = new ContactService();
		Contact c = new Contact ("1", "John", "Smith", "1234567890", "123 Main St");
		
		service.addContact(c);
		service.updateLastName("1", "Smith");
		
		assertEquals("Smith", c.getLastName());
	}
	
	// Test for updating phone number
	@Test
	public void testPhoneNumber() {
		ContactService service = new ContactService();
		Contact c = new Contact ("1", "John", "Smith", "1234567890", "123 Main St");
		
		service.addContact(c);
		service.updatePhone("1", "0987654321");
		
		assertEquals("0987654321", c.getPhone());
	}
	
	// Test for updating street address
	@Test
	public void testStreetAddress() {
		ContactService service = new ContactService();
		Contact c = new Contact ("1", "John", "Smith", "1234567890", "123 Main St");
		
		service.addContact(c);
		service.updateAddress("1", "232 Main St");
		
		assertEquals("232 Main St", c.getAddress());
		
	}

}
