package contacts;

import java.util.HashMap;
import java.util.Map;

public class ContactService {
	
	// Store contacts via a HashMap
	private Map<String, Contact> contacts = new HashMap<>();
	
	// Add contact
	public void addContact(Contact contact) {
		if (contacts.containsKey(contact.getcontactID())) {
			throw new IllegalArgumentException("Duplicate contact ID");
		}
		contacts.put(contact.getcontactID(), contact);
	}
	
	// Delete the contact
	public void deleteContact(String contactID) {
		contacts.remove(contactID);
	}
	
	// Update first name
	public void updateFirstName(String contactID, String newName) {
		Contact c = contacts.get(contactID);
		c.setFirstName(newName);
	}
	
	// Update last name
	public void updateLastName(String contactID, String newName) {
		Contact c = contacts.get(contactID);
		c.setLastName(newName);
	}
	
	// Update phone number
	public void updatePhone(String contactID, String newPhone) {
		Contact c = contacts.get(contactID);
		c.setPhone(newPhone);
	}
	
	// Update the address
	public void updateAddress(String contactID, String newAddress) {
		Contact c = contacts.get(contactID);
		c.setAddress(newAddress);
	}

}
