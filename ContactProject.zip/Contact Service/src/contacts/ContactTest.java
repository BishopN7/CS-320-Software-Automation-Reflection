package contacts;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class ContactTest {
	
	@Test
	public void testValidContactCreation() {
		Contact c = new Contact("12345", "John", "Smith", "1234567890", "123 Main Street");
		assertEquals("John", c.getFirstName());
		assertEquals("Smith", c.getLastName());
	}
	
	@Test
	public void testContactIDTooLong() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678901", "John", "Smith", "1234567890", "123 Main Street");
		});
	}
	
	@Test 
	public void testFirstNameNull() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", null, "Smith", "1234567890", "123 Main Street");
		});
	}
	
	@Test
	public void testPhoneNotTenDigits() {
		assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", "John", "Smith", "12345678", "123 Main Street");
		});
	}
		
	@Test
	public void testUpdateFirstName() {
		Contact c = new Contact("123", "John", "Smith", "1234567890", "123 Main Street");
		c.setFirstName("NewName");
		assertEquals("NewName", c.getFirstName());
	  }
   }


